package application;

import java.util.Scanner;
import java.sql.SQLException;

public class MarketPlace {

    public MarketPlace() {
    }

   
}
